from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="rudrr-cli",
    version="1.0.0",
    author="rudrr08",
    description="⚡ A cool multi-tool CLI by rudrr08",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/rudrr08/rudrr-cli",
    packages=find_packages(),
    python_requires=">=3.8",
    install_requires=[
        "click>=8.0",
    ],
    entry_points={
        "console_scripts": [
            "rudrr=rudrr_cli.main:cli",
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Environment :: Console",
    ],
)
