"""Basic tests for rudrr-cli"""

from click.testing import CliRunner
from rudrr_cli.main import cli


def test_hello_default():
    runner = CliRunner()
    result = runner.invoke(cli, ["hello"])
    assert result.exit_code == 0
    assert "Hello, world!" in result.output


def test_hello_with_name():
    runner = CliRunner()
    result = runner.invoke(cli, ["hello", "--name", "Rudrr"])
    assert "Hello, Rudrr!" in result.output


def test_hello_shout():
    runner = CliRunner()
    result = runner.invoke(cli, ["hello", "--name", "rudrr", "--shout"])
    assert "HELLO, RUDRR!" in result.output


def test_hash_sha256():
    runner = CliRunner()
    result = runner.invoke(cli, ["hash", "rudrr08"])
    assert result.exit_code == 0
    assert "SHA256" in result.output


def test_hash_md5():
    runner = CliRunner()
    result = runner.invoke(cli, ["hash", "rudrr08", "--algo", "md5"])
    assert result.exit_code == 0


def test_b64_encode():
    runner = CliRunner()
    result = runner.invoke(cli, ["b64", "hello"])
    assert "aGVsbG8=" in result.output


def test_b64_decode():
    runner = CliRunner()
    result = runner.invoke(cli, ["b64", "aGVsbG8=", "--decode"])
    assert "hello" in result.output


def test_time():
    runner = CliRunner()
    result = runner.invoke(cli, ["time"])
    assert result.exit_code == 0


def test_banner():
    runner = CliRunner()
    result = runner.invoke(cli, ["banner"])
    assert "rudrr08" in result.output
