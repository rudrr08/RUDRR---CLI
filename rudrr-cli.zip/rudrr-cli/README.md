# ⚡ rudrr-cli

> A cool multi-tool command-line toolkit — built by [rudrr08](https://github.com/rudrr08)

![Python](https://img.shields.io/badge/Python-3.8+-blue?style=flat-square&logo=python)
![License](https://img.shields.io/badge/License-MIT-green?style=flat-square)
![Version](https://img.shields.io/badge/Version-1.0.0-purple?style=flat-square)

---

## 🚀 Features

| Command | What it does |
|---------|-------------|
| `rudrr hello` | Greet someone (or shout at them) |
| `rudrr hash <text>` | Hash any string with md5/sha1/sha256/sha512 |
| `rudrr time` | Show current date & time (local or UTC) |
| `rudrr scan <path>` | Scan a directory and show file sizes |
| `rudrr b64 <text>` | Base64 encode or decode a string |
| `rudrr banner` | Print the sick ASCII banner |

---

## 📦 Installation

### Option 1 — Clone & install locally

```bash
git clone https://github.com/rudrr08/rudrr-cli.git
cd rudrr-cli
pip install -e .
```

### Option 2 — Install dependencies only

```bash
pip install -r requirements.txt
python -m rudrr_cli.main --help
```

---

## 🛠 Usage

```bash
# Get help
rudrr --help

# Say hello
rudrr hello
rudrr hello --name Rudrr
rudrr hello --name Rudrr --shout

# Hash a string
rudrr hash "rudrr08"
rudrr hash "rudrr08" --algo md5
rudrr hash "rudrr08" --algo sha512

# Current time
rudrr time
rudrr time --utc
rudrr time --utc --unix

# Scan a directory
rudrr scan .
rudrr scan /path/to/folder --ext .py

# Base64
rudrr b64 "hello world"
rudrr b64 "aGVsbG8gd29ybGQ=" --decode

# Banner
rudrr banner
```

---

## 🧪 Running Tests

```bash
pip install pytest
pytest tests/ -v
```

---

## 📁 Project Structure

```
rudrr-cli/
├── rudrr_cli/
│   ├── __init__.py      # Package info
│   └── main.py          # All CLI commands
├── tests/
│   └── test_cli.py      # Test suite
├── .gitignore
├── LICENSE
├── README.md
├── requirements.txt
└── setup.py
```

---

## 🤝 Contributing

Pull requests are welcome! Feel free to open an issue for bugs or feature ideas.

---

## 📄 License

MIT © [rudrr08](https://github.com/rudrr08)

---

<p align="center">Made with ⚡ by <a href="https://github.com/rudrr08">rudrr08</a></p>
