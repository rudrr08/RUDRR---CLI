"""rudrr-cli — a cool toolkit by rudrr08"""
__version__ = "1.0.0"
__author__ = "rudrr08"
