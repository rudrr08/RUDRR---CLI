#!/usr/bin/env python3
"""
rudrr-cli ⚡
A cool multi-tool CLI by rudrr08
"""

import click
import sys
import os
import hashlib
import datetime
from pathlib import Path


# ─── Styling helpers ──────────────────────────────────────────────────────────

COLORS = {
    "cyan":   "\033[96m",
    "green":  "\033[92m",
    "yellow": "\033[93m",
    "red":    "\033[91m",
    "purple": "\033[95m",
    "bold":   "\033[1m",
    "reset":  "\033[0m",
}

def c(text, color):
    return f"{COLORS[color]}{text}{COLORS['reset']}"

BANNER = f"""
{COLORS['cyan']}{COLORS['bold']}
  ██████╗ ██╗   ██╗██████╗ ██████╗ ██████╗      ██████╗██╗     ██╗
  ██╔══██╗██║   ██║██╔══██╗██╔══██╗██╔══██╗    ██╔════╝██║     ██║
  ██████╔╝██║   ██║██║  ██║██████╔╝██████╔╝    ██║     ██║     ██║
  ██╔══██╗██║   ██║██║  ██║██╔══██╗██╔══██╗    ██║     ██║     ██║
  ██║  ██║╚██████╔╝██████╔╝██║  ██║██║  ██║    ╚██████╗███████╗██║
  ╚═╝  ╚═╝ ╚═════╝ ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝    ╚═════╝╚══════╝╚═╝
{COLORS['reset']}{COLORS['purple']}  ⚡ built by rudrr08 · github.com/rudrr08{COLORS['reset']}
"""


# ─── CLI Group ────────────────────────────────────────────────────────────────

@click.group()
@click.version_option("1.0.0", prog_name="rudrr-cli")
def cli():
    """⚡ rudrr-cli — your personal command-line toolkit."""
    pass


# ─── hello ────────────────────────────────────────────────────────────────────

@cli.command()
@click.option("--name", "-n", default="world", help="Who to greet.")
@click.option("--shout", is_flag=True, help="SHOUT the greeting.")
def hello(name, shout):
    """Say hello. A classic, but make it ⚡."""
    print(BANNER)
    msg = f"Hello, {name}! ⚡"
    if shout:
        msg = msg.upper()
    click.echo(c(msg, "cyan"))


# ─── hash ─────────────────────────────────────────────────────────────────────

@cli.command()
@click.argument("text")
@click.option("--algo", "-a",
              type=click.Choice(["md5", "sha1", "sha256", "sha512"], case_sensitive=False),
              default="sha256", show_default=True,
              help="Hashing algorithm to use.")
def hash(text, algo):
    """Hash any text string instantly."""
    h = hashlib.new(algo)
    h.update(text.encode())
    result = h.hexdigest()
    click.echo(c(f"\n  Input : ", "yellow") + text)
    click.echo(c(f"  Algo  : ", "yellow") + algo.upper())
    click.echo(c(f"  Hash  : ", "green") + c(result, "bold"))
    click.echo()


# ─── time ─────────────────────────────────────────────────────────────────────

@cli.command(name="time")
@click.option("--utc", is_flag=True, help="Show UTC time instead of local.")
@click.option("--unix", is_flag=True, help="Show Unix timestamp.")
def time_cmd(utc, unix):
    """Show the current date and time."""
    now = datetime.datetime.utcnow() if utc else datetime.datetime.now()
    label = "UTC" if utc else "Local"

    click.echo(c(f"\n  ⏰ {label} Time", "purple"))
    click.echo(c(f"  Date      : ", "yellow") + now.strftime("%A, %d %B %Y"))
    click.echo(c(f"  Time      : ", "yellow") + c(now.strftime("%H:%M:%S"), "cyan"))
    if unix:
        ts = int(datetime.datetime.utcnow().timestamp())
        click.echo(c(f"  Unix      : ", "yellow") + str(ts))
    click.echo()


# ─── scan ─────────────────────────────────────────────────────────────────────

@cli.command()
@click.argument("path", default=".", type=click.Path(exists=True))
@click.option("--ext", "-e", default=None, help="Filter by extension (e.g. .py)")
def scan(path, ext):
    """Scan a directory and show file info."""
    p = Path(path).resolve()
    files = list(p.rglob("*") if p.is_dir() else [p])

    if ext:
        files = [f for f in files if f.suffix == ext]

    files = [f for f in files if f.is_file()]

    click.echo(c(f"\n  📁 Scanning: {p}", "purple"))
    click.echo(c(f"  Found {len(files)} file(s)\n", "yellow"))

    total_bytes = 0
    for f in sorted(files):
        size = f.stat().st_size
        total_bytes += size
        size_str = f"{size:,} B" if size < 1024 else f"{size/1024:.1f} KB"
        rel = f.relative_to(p) if f.is_relative_to(p) else f
        click.echo(f"  {c('▸', 'cyan')} {rel}  {c(size_str, 'green')}")

    click.echo(c(f"\n  Total: {total_bytes/1024:.1f} KB across {len(files)} files\n", "yellow"))


# ─── encode / decode ──────────────────────────────────────────────────────────

@cli.command()
@click.argument("text")
@click.option("--decode", "-d", is_flag=True, help="Decode instead of encode.")
def b64(text, decode):
    """Base64 encode or decode a string."""
    import base64
    try:
        if decode:
            result = base64.b64decode(text.encode()).decode()
            label = "Decoded"
        else:
            result = base64.b64encode(text.encode()).decode()
            label = "Encoded"
        click.echo(c(f"\n  {label}: ", "yellow") + c(result, "cyan") + "\n")
    except Exception as e:
        click.echo(c(f"\n  ✗ Error: {e}\n", "red"))


# ─── banner ───────────────────────────────────────────────────────────────────

@cli.command()
def banner():
    """Print the rudrr-cli banner."""
    print(BANNER)


# ─── Entry point ──────────────────────────────────────────────────────────────

if __name__ == "__main__":
    cli()
